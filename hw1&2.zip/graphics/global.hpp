//
// Created by 87549 on 2022/5/24.
//

#ifndef GRAPHICS_GLOBAL_HPP
#define GRAPHICS_GLOBAL_HPP

//#define MY_PI 3.1415926
//#define TWO_PI (2.0* MY_PI)
#endif //GRAPHICS_GLOBAL_HPP
